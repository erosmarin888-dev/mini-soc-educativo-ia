## Objetivo

## Cambios

## Validación

- [ ] Ejecuté `npm test`.
- [ ] Probé `index.html` desde `file://`.
- [ ] Probé diseño móvil y navegación por teclado.
- [ ] No agregué datos reales, secretos, IOCs activos ni llamadas de red.
- [ ] Actualicé la documentación y el changelog.
